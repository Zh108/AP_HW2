import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        BankSystem bank = new BankSystem();

        while (true) {
            String line = scanner.nextLine();
            String result = bank.processCommand(line);
            if (result != null && !result.isEmpty()) {
                System.out.println(result);
            }
            if ("Goodbye!".equals(result)) {
                break;
            }
        }

        scanner.close();
    }



    }
