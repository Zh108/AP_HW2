import java.util.ArrayList;
import java.util.List;

public class BankSystem {

    private List<User> users = new ArrayList<>();
    private User currentUser = null;
    private static long nextCardNumber = 6037000000000000L;


    public String processCommand(String line) {
        if (line == null || line.trim().isEmpty()) return "";
        String[] parts = line.trim().split("\\s+");

        String cmd = parts[0].toLowerCase();

        switch (cmd) {
            case "register":
                return handleRegister(parts);
            case "login":
                return handleLogin(parts);
            case "show":
                return handleShow(parts);
            case "deposit":
                return handleDeposit(parts);
            case "withdraw":
                return handleWithdraw(parts);
            case "transfer":
                return handleTransfer(parts);
            case "logout":
                return handleLogout();
            case "exit":
                return "Goodbye!";
            default:
                return "Error: invalid command.";
        }
    }


    // register <UserName> <Password> <FullName> <PhoneNumber> <Email>
    private String handleRegister(String[] parts) {
        if (parts.length < 7) {
            return "Error: invalid arguments for register.";
        }

        String username = parts[1];
        String password = parts[2];
        String firstName = parts[3];
        String lastName = parts[4];
        String fullName = firstName + " " + lastName;
        String phone = parts[5];
        String email = parts[6];

        if (findUserByUsername(username) != null) {
            return "Error: username already exists.";
        }


        if (!isValidPhone(phone)) {
            return "Error: invalid phone number.";
        }

        if (!isValidEmail(email)) {
            return "Error: invalid email.";
        }

        if (!isValidPassword(password)) {
            return "Error: invalid password.";
        }


        String cardNumber = String.valueOf(nextCardNumber++);
        User user = new User(username, password, fullName, phone, email, cardNumber);
        users.add(user);

        return "Registered successfully.\nAssigned card number: " + cardNumber;
    }


    //login <UserName> <Password>
    private String handleLogin(String[] parts) {
        if (parts.length < 3) {
            return "Error: invalid arguments for login.";
        }

        String username = parts[1];
        String password = parts[2];

        User user = findUserByUsername(username);
        if (user == null || !user.getPassword().equals(password)) {
            return "Error: invalid username or password.";
        }

        currentUser = user;
        return "Login successful.";
    }

    //show balance
    private String handleShow(String[] parts) {
        if (parts.length >= 2 && parts[1].equalsIgnoreCase("balance")) {
            if (currentUser == null) {
                return "Error: You should login first.";
            }
            return "Current balance: " + currentUser.getBalance();
        }
        return "Error: invalid show command.";
    }

    //deposit <amount>
    private String handleDeposit(String[] parts) {
        if (currentUser == null) {
            return "Error: You should login first.";
        }
        if (parts.length < 2) {
            return "Error: invalid arguments for deposit.";
        }

        try {
            double amount = Double.parseDouble(parts[1]);
            if (amount <= 0) {
                return "Error: amount must be positive.";
            }
            currentUser.deposit(amount);
            return "Deposit successful. Current balance: " + currentUser.getBalance();
        } catch (NumberFormatException e) {
            return "Error: invalid amount.";
        }
    }


    //withdraw <amount>
    private String handleWithdraw(String[] parts) {
        if (currentUser == null) {
            return "Error: You should login first.";
        }
        if (parts.length < 2) {
            return "Error: invalid arguments for withdraw.";
        }

        try {
            double amount = Double.parseDouble(parts[1]);
            if (amount <= 0) {
                return "Error: amount must be positive.";
            }

            if (!currentUser.withdraw(amount)) {
                return "Error: balance is not enough.";
            }
            return "Withdraw successful. Current balance: " + currentUser.getBalance();
        } catch (NumberFormatException e) {
            return "Error: invalid amount.";
        }
    }


    //transfer <CardNumber> <amount>
    private String handleTransfer(String[] parts) {
        if (currentUser == null) {
            return "Error: You should login first.";
        }
        if (parts.length < 3) {
            return "Error: invalid arguments for transfer.";
        }

        String destCard = parts[1];

        try {
            double amount = Double.parseDouble(parts[2]);
            if (amount <= 0) {
                return "Error: amount must be positive.";
            }

            User destUser = findUserByCard(destCard);
            if (destUser == null) {
                return "Error: invalid card number.";
            }

            if (!currentUser.withdraw(amount)) {
                return "Error: balance is not enough.";
            }

            destUser.deposit(amount);
            return "Transferred successfully.";
        } catch (NumberFormatException e) {
            return "Error: invalid amount.";
        }
    }

    //logout
    private String handleLogout() {
        if (currentUser == null) {
            return "Error: no user is logged in.";
        }
        currentUser = null;
        return "Logout successful.";
    }



    private User findUserByUsername(String username) {
        for (User u : users) {
            if (u.getUsername().equals(username)) return u;
        }
        return null;
    }

    private User findUserByCard(String cardNumber) {
        for (User u : users) {
            if (u.getCardNumber().equals(cardNumber)) return u;
        }
        return null;
    }

    // 09XXXXXXXXX
    private boolean isValidPhone(String phone){
        if(phone.length() != 11) return false;
        if(phone.charAt(0)!='0' || phone.charAt(1)!='9') return false;

        for(int i=0;i<phone.length();i++){
            //if(phone.charAt(i) < '0' || phone.charAt(i) > '9') return false;
            if (!Character.isDigit(phone.charAt(i)) ) return false;
        }
        return true;
    }

    private boolean isValidEmail(String email){

        if(email.charAt(0) == '.')
            return false;

        int atPos = -1;
        for(int i=0;i<email.length();i++){
            if(email.charAt(i)=='@'){
                atPos = i;
                break;
            }
        }

        if(atPos <= 0)
            return false;

        String beforeAt = email.substring(0, atPos);
        String afterAt  = email.substring(atPos+1);

        if(beforeAt.length() < 1 || beforeAt.equals("."))
            return false;

        if(!afterAt.equals("aut.com"))
            return false;

        return true;
    }

    private boolean isValidPassword(String pass){
        if(pass.length() < 8) return false;
        boolean lower=false, upper=false, digit=false, special=false;

        for(char ch : pass.toCharArray()){
            if(ch>='a' && ch<='z') lower=true;
            else if(ch>='A' && ch<='Z') upper=true;
            else if(ch>='0' && ch<='9') digit=true;
            else if(ch=='@' || ch=='!' || ch=='$' || ch==',' || ch=='&') special=true;
        }

        return lower && upper && digit && special;
    }

}
