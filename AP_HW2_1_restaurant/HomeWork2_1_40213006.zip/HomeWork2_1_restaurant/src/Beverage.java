public class Beverage extends MenuItem{
    private int size;
    private int temperature;
    private static final String[] size_list = {"small","medium","large"};
    private static final String[] temperature_list = {"cold","hot"};
    public Beverage(String itemId, String name, double price, String category, int size, int temperature) {
        super(itemId, name, price, category);
        this.size = size;
        this.temperature = temperature;
    }
    //getter
    public int getSize() {
        return size;
    }
    public int getTemperature() {
        return temperature;
    }
    //setter
    public void setSize(int size) {
        this.size = size;
    }
    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }


    public void getDetails() {
        System.out.println("ID: " + getItemId() +
                           ", Name: " + getName() +
                           ", Price: " + getPrice() +
                           ", Category: " + getCategory() +
                           ", Size" + size_list[getSize()] +
                           ", Temperature" + temperature_list[getTemperature()]);
    }

    @Override
    public String toString() {
        return "ID: " + getItemId() +
               ", Name: " + getName() +
               ", Price: " + getPrice() +
               ", Category: " + getCategory() +
               ", Size" + size_list[getSize()] +
               ", Temperature" + temperature_list[getTemperature()];
    }
}
