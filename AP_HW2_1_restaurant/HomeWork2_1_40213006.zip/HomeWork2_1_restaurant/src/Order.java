import java.util.ArrayList;

public class Order {
    private static int nobat;
    private int OrderId;
    private Customer customer;
    private final ArrayList<MenuItem> items = new ArrayList<>();
    private double totalAmount;

    public Order(Customer customer) {
        this.OrderId = nobat++;
        this.customer = customer;
    }

    public void addItem(MenuItem item){
        items.add(item);
    }

    public double calculateTotal() {
        double sum = 0;
        for (MenuItem item : items) {
            sum += item.getPrice();
        }
        customer.addLoyaltyPoints(sum);
        double discount = customer.getDiscount();
        totalAmount = Math.round(sum * (1.0 - discount)); 
        return totalAmount;
    }

    public void getOrderSummary(){
        System.out.println("Order Id: " + OrderId +
                           ", Customer: " + customer.getName() +
                           ", Total Amount: " + totalAmount);
        System.out.println("Items: ");
                           for (int i = 0; i < items.size(); i++) {
                               System.out.print(items.get(i).getName());
                               if (i < items.size() - 1) System.out.print(" - ");
                           }

    }


    //getter
    public int getOrderId() {return OrderId;}
    public Customer getCustomer() {return customer;}
    public ArrayList<MenuItem> getItems() {return items;}
    public double getTotalAmount() {return totalAmount;}
    //setter
    public void setOrderId(int OrderId){
        this.OrderId = OrderId;
    }
    public void setCustomer(Customer customer){
        this.customer = customer;
    }
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

}
