public class Employee extends Person{
    private String employeeId;
    private String position;
    private double salary;
    private double housrsWorked;

    Employee(String name,String phoneNumber, String employeeId, String position,  double salary, double housrsWorked){
        super(name,phoneNumber);
        this.employeeId = employeeId;
        this.position = position;
        this.salary = salary;
        this.housrsWorked = housrsWorked;
    }

    public void addHoursWorked(double hours){
        if (hours >= 0){
            this.housrsWorked += hours;
        }
        else{
            System.out.println("Invalid hours");
        }

    }



    public double calculateSalary(){
        if (housrsWorked < 160){
            System.out.println("hoursWorked is less than 160");
            return 0;
        }
        else{
            double ezafekari = housrsWorked - 160; // manzooresho daghigh az paye hoghoogh nafahmidam :)
            return (salary + (ezafekari/160) * (salary * 1.5));
        }
    }

    // getter
    public String getEmployeeId() {
        return employeeId;
    }
    public String getPosition() {
        return position;
    }
    public double getSalary() {
        return salary;
    }
    public double getHousrsWorked() {
        return housrsWorked;
    }

    // setter
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public void setHousrsWorked(double housrsWorked) {
        this.housrsWorked = housrsWorked;
    }

    public void getInfo(){
        System.out.println("ID: " + employeeId + ", Name: " + this.getName() + ", Phone: " + this.getPhoneNumber() + ", Position: " + this.getPosition() + ", HoursWorked: " + this.housrsWorked);
    }

}
