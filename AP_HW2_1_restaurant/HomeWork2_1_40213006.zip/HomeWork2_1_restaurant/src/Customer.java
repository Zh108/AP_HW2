public class Customer extends Person{

    private String customerID;
    private int loyaltyPoints;

    Customer(String name,String phoneNumber, String customerID , int loyaltyPoints) {
        super(name,phoneNumber);
        this.customerID = customerID;
        this.loyaltyPoints = loyaltyPoints;
    }

    public void addLoyaltyPoints(double paid){
        if (paid >= 1000000){
            this.loyaltyPoints += 2;
        }
        else if (paid >= 500000){ // agar jofteshon ro if bezarim agar balaye 1m bashe +3 mishe!
            this.loyaltyPoints ++;
        }


    }

    public double getDiscount(){
        if (loyaltyPoints > 5){
            return 0.1;
        }
        else if (loyaltyPoints > 3){
            return 0.05;
        }
        return 0.0;
    }

    public void getInfo(){
        System.out.println("ID: " + this.customerID + ", Name: " + this.getName() + ", Phone: " + this.getPhoneNumber() + ", Loyalty Points: " + this.loyaltyPoints );
    }

    //getter
    public String getCustomerID() {return customerID;}
    public int getLoyaltyPoints() {return loyaltyPoints;}
    //setter
    public void setCustomerID(String customerID) {this.customerID = customerID;}
    public void setLoyaltyPoints(int loyaltyPoints) {this.loyaltyPoints = loyaltyPoints;}
}
