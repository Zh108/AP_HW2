public class Food extends MenuItem {
    private int spiceLevel; // mild=0 - medium=1 - spicy=3
    private static final String[] spiceLevel_list = {"mild","medium","spicy"};
    private int preparationTime; //minutes

    public Food(String itemId, String name, double price, String category, int spiceLevel, int preparationTime){
        super(itemId, name, price, category);
        this.spiceLevel = spiceLevel;
        this.preparationTime = preparationTime;
    }

    //getter
    public int getSpiceLevel() {
        return spiceLevel;
    }
    public int getPreparationTime() {
        return preparationTime;
    }
    //setter
    public void setSpiceLevel(int spiceLevel) {
        this.spiceLevel = spiceLevel;
    }
    public void setPreparationTime(int preparationTime) {
        this.preparationTime = preparationTime;
    }
    public void getDetails(){
        System.out.println("ID: " + getItemId() + ", Name: " + getName() + ", Price: " + getPrice() + ", Category: " + getCategory() + ", Spice: " + spiceLevel_list[getSpiceLevel()] + ", Preparation Time: " + getPreparationTime() + "min");
    }

    @Override
    public String toString() {
        return "ID: " + getItemId() +
                ", Name: " + getName() +
                ", Price: " + getPrice() +
                ", Category: " + getCategory() +
                ", Spice: " + spiceLevel_list[getSpiceLevel()] +
                ", Preparation Time: " + getPreparationTime() + " min";
    }


}
