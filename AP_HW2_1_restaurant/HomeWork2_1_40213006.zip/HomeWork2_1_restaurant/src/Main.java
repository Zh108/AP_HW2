import java.util.*;

public class Main {
    public static void main(String[] args) {

        //   EMPLOYEE
        Employee e1 = new Employee("Maryam", "09131234567", "E001" ,"chef", 800000 , 178);      // 800,000
        Employee e2 = new Employee("Reza",   "09120000000","E002", "accountant", 900000 , 160);
        Employee e3 = new Employee("Sara",   "09350000000", "E003","front-desk", 700000 , 190);

        //  CUSTOMER
        Customer c1 = new Customer("Ali",    "09301111111", "C001" , 0);
        Customer c2 = new Customer("Neda",   "09121111111", "C002" , 0);
        Customer c3 = new Customer("Hamed",  "09122222222", "C003" , 0);
        Customer c4 = new Customer("Leila",  "09123333333", "C004" , 0);
        Customer c5 = new Customer("Omid",   "09124444444", "C005" , 0);
        List<Customer> customers = List.of(c1,c2,c3,c4,c5);

        //  MENU
        Food pizza = new Food("1", "Pizza", 400000, "pizza", 2 , 25);
        Food kebab = new Food("3", "Kebab", 520000, "kebab",1 , 20);
        Food curry = new Food("4", "Curry", 470000, "curry", 3, 30);

        Beverage tea   = new Beverage("2", "Tea", 60000, "tea" ,3,  1);
        Beverage soda  = new Beverage("5", "Soda", 80000,"soda", 2, 0);
        Beverage latte = new Beverage("6", "Latte", 120000,"coffee", 1, 1);

        List<MenuItem> menu = List.of(pizza, kebab, curry, tea, soda, latte);

        //  ORDERS
        // c1: Ali
        Order o11 = new Order(c1);
        o11.addItem(pizza);
        o11.addItem(soda);
        o11.calculateTotal();

        Order o12 = new Order(c1);
        o12.addItem( kebab);
        o12.calculateTotal();

        Order o13 = new Order(c1);
        o13.addItem(curry);
        o13.calculateTotal();

        // c2: Neda
        Order o21 = new Order(c2);
        o21.addItem( kebab);
        o21.addItem( curry);
        o21.addItem( soda);
        o21.calculateTotal();

        Order o22 = new Order(c2);
        o22.addItem(pizza);
        o22.addItem(soda);
        o22.calculateTotal();

        Order o23 = new Order(c2);
        o23.addItem(curry);
        o23.addItem(tea);
        o23.calculateTotal();

        // c3: Hamed
        Order o31 = new Order(c3);
        o31.addItem(pizza);
        o31.addItem(kebab);
        o31.calculateTotal();

        Order o32 = new Order(c3);
        o32.addItem(curry);
        o32.addItem(tea);
        o32.calculateTotal();

        Order o33 = new Order(c3);
        o33.addItem(pizza);
        o33.addItem(soda);
        o33.addItem(latte);
        o33.calculateTotal();

        // c4: Leila
        Order o41 = new Order(c4);
        o41.addItem(kebab);
        o41.addItem(kebab);
        o41.addItem(tea);
        o41.calculateTotal();

        Order o42 = new Order(c4);
        o42.addItem(pizza);
        o42.addItem(curry);
        o42.calculateTotal();

        Order o43 = new Order(c4);
        o43.addItem(latte);
        o43.addItem(latte);
        o43.addItem(tea);
        o43.calculateTotal();

        // c5: Omid
        Order o51 = new Order(c5);
        o51.addItem(curry);
        o51.calculateTotal();

        Order o52 = new Order(c5);
        o52.addItem(pizza);
        o52.calculateTotal();

        Order o53 = new Order(c5);
        o53.addItem( kebab);
        o53.calculateTotal();


        // SALARIES
        System.out.println(e1.getEmployeeId() + " salary: " + e1.calculateSalary());
        System.out.println(e2.getEmployeeId() + " salary: " + e2.calculateSalary());
        System.out.println(e3.getEmployeeId() + " salary: " + e3.calculateSalary());

        // Most loyal customer
        int best = -1;
        List<Customer> top = new ArrayList<>();

        for (Customer c : customers) {
            int p = c.getLoyaltyPoints();
            if (p > best) {
                best = p;
                top.clear();
                top.add(c);
            } else if (p == best) {
                top.add(c);
            }
        }

        if (best >= 0) {
            System.out.print("Most loyal: ");
            for (int i = 0; i < top.size(); i++) {
                Customer c = top.get(i);
                System.out.print(c.getName() + " (" + c.getLoyaltyPoints() + ")");
                if (i < top.size() - 1) System.out.print(", ");
            }
            System.out.println();
        } else {
            System.out.println("Most loyal: N/A");
        }



    }
}